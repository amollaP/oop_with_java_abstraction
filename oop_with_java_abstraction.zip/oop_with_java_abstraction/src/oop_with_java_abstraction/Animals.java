package oop_with_java_abstraction;

//Interface em Java
//Todas as classes que implementam a Interface, obrigatoriamente, irão implementar seus respectivos "PROCEDURES AND FUNCTIONS"
interface Animals {
    //metodos geral que o ANimal faz
    void comer();
    void som();
}

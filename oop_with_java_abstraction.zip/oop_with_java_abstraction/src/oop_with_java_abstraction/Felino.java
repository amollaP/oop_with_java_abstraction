package oop_with_java_abstraction;


public abstract class Felino extends Animal{
	
    //Metodo brincar é da Classe Felino
    abstract void brincar();
    
}
